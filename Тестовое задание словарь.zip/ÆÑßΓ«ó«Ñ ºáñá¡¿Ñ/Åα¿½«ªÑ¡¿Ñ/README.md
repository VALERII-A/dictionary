Приложение англо-русский словарь с возможностью добавления слов, тестирования с выводом результата,
Добавления в словарь слов с переводом из csv файла.
Реализация на vue. Js, вёрстка по методологии БЭМ. 

## Project setup
```
npm install
```

### Compiles and hot-reloads for development
```
npm run serve
```

### Compiles and minifies for production
```
npm run build
```

### Lints and fixes files
```
npm run lint
```

### Customize configuration
See [Configuration Reference](https://cli.vuejs.org/config/).
